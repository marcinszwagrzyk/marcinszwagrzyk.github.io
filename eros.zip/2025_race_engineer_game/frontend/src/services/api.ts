import { RaceState, DriverOrder, TireCompound } from '../types/game.types';

const API_BASE = '/api/race';

export async function createRace(): Promise<RaceState> {
  const response = await fetch(`${API_BASE}/create`, { method: 'POST' });
  return response.json();
}

export async function startRace(): Promise<void> {
  await fetch(`${API_BASE}/start`, { method: 'POST' });
}

export async function pauseRace(): Promise<void> {
  await fetch(`${API_BASE}/pause`, { method: 'POST' });
}

export async function getRaceState(): Promise<RaceState> {
  const response = await fetch(`${API_BASE}/state`);
  return response.json();
}

export async function setDriverOrder(carId: number, order: DriverOrder): Promise<void> {
  await fetch(`${API_BASE}/order`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ carId, order })
  });
}

export async function callToPit(carId: number, tireCompound: TireCompound): Promise<void> {
  await fetch(`${API_BASE}/pit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ carId, tireCompound })
  });
}
