import { CarTelemetry } from '../types/game.types';
import './Telemetry.css';

interface TelemetryProps {
  car: CarTelemetry | null;
}

export function Telemetry({ car }: TelemetryProps) {
  if (!car) {
    return <div className="telemetry">No car data</div>;
  }

  const formatTime = (seconds: number): string => {
    if (seconds <= 0 || seconds === Infinity) return '--:--.---';
    const mins = Math.floor(seconds / 60);
    const secs = (seconds % 60).toFixed(3);
    return `${mins}:${secs.padStart(6, '0')}`;
  };

  return (
    <div className="telemetry">
      <h3>Telemetry</h3>

      <div className="telemetry-section">
        <div className="telemetry-label">Position</div>
        <div className="telemetry-value large">P{car.racePosition}</div>
      </div>

      <div className="telemetry-section">
        <div className="telemetry-label">Lap</div>
        <div className="telemetry-value">{car.currentLap}</div>
      </div>

      <div className="telemetry-section">
        <div className="telemetry-label">Last Lap</div>
        <div className="telemetry-value">{formatTime(car.lastLapTime)}</div>
      </div>

      <div className="telemetry-section">
        <div className="telemetry-label">Best Lap</div>
        <div className="telemetry-value best">{formatTime(car.bestLapTime)}</div>
      </div>

      <div className="telemetry-bar-section">
        <div className="telemetry-label">
          Fuel <span className="value">{car.fuelLevel.toFixed(1)}%</span>
        </div>
        <div className="bar-container">
          <div
            className={`bar fuel ${car.fuelLevel < 20 ? 'critical' : ''}`}
            style={{ width: `${car.fuelLevel}%` }}
          />
        </div>
      </div>

      <div className="telemetry-bar-section">
        <div className="telemetry-label">
          Tires ({car.tireCompound}) <span className="value">{(100 - car.tireWear).toFixed(1)}%</span>
        </div>
        <div className="bar-container">
          <div
            className={`bar tires ${car.tireWear > 70 ? 'critical' : ''}`}
            style={{ width: `${100 - car.tireWear}%` }}
          />
        </div>
      </div>

      <div className="telemetry-bar-section">
        <div className="telemetry-label">
          Fatigue <span className="value">{car.fatigueLevel.toFixed(1)}%</span>
        </div>
        <div className="bar-container">
          <div
            className={`bar fatigue ${car.fatigueLevel > 70 ? 'critical' : car.fatigueLevel > 50 ? 'warning' : ''}`}
            style={{ width: `${car.fatigueLevel}%` }}
          />
        </div>
      </div>

      <div className="telemetry-section">
        <div className="telemetry-label">Current Order</div>
        <div className={`telemetry-value order ${car.currentOrder.toLowerCase()}`}>
          {car.currentOrder}
        </div>
      </div>
    </div>
  );
}
