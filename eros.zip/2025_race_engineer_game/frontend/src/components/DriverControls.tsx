import { useState } from 'react';
import { DriverOrder, TireCompound, CarTelemetry } from '../types/game.types';
import { setDriverOrder, callToPit } from '../services/api';
import './DriverControls.css';

interface DriverControlsProps {
  car: CarTelemetry | null;
}

export function DriverControls({ car }: DriverControlsProps) {
  const [selectedCompound, setSelectedCompound] = useState<TireCompound>('MEDIUM');

  if (!car) {
    return <div className="driver-controls">No car selected</div>;
  }

  const handleOrderChange = async (order: DriverOrder) => {
    await setDriverOrder(car.carId, order);
  };

  const handlePitCall = async () => {
    await callToPit(car.carId, selectedCompound);
  };

  return (
    <div className="driver-controls">
      <h3>Driver Orders</h3>

      <div className="order-buttons">
        <button
          className={`order-btn push ${car.currentOrder === 'PUSH' ? 'active' : ''}`}
          onClick={() => handleOrderChange('PUSH')}
        >
          PUSH
        </button>
        <button
          className={`order-btn normal ${car.currentOrder === 'NORMAL' ? 'active' : ''}`}
          onClick={() => handleOrderChange('NORMAL')}
        >
          NORMAL
        </button>
        <button
          className={`order-btn conserve ${car.currentOrder === 'CONSERVE' ? 'active' : ''}`}
          onClick={() => handleOrderChange('CONSERVE')}
        >
          CONSERVE
        </button>
      </div>

      <div className="pit-section">
        <h4>Pit Stop</h4>
        <div className="compound-select">
          {(['SOFT', 'MEDIUM', 'HARD'] as TireCompound[]).map((compound) => (
            <button
              key={compound}
              className={`compound-btn ${compound.toLowerCase()} ${selectedCompound === compound ? 'selected' : ''}`}
              onClick={() => setSelectedCompound(compound)}
            >
              {compound}
            </button>
          ))}
        </div>
        <button
          className="pit-btn"
          onClick={handlePitCall}
          disabled={car.inPit}
        >
          {car.inPit ? 'IN PIT' : 'BOX BOX BOX'}
        </button>
      </div>
    </div>
  );
}
