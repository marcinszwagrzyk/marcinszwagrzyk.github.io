import { CarTelemetry } from '../types/game.types';
import './Leaderboard.css';

interface LeaderboardProps {
  cars: CarTelemetry[];
  totalLaps: number;
}

export function Leaderboard({ cars, totalLaps }: LeaderboardProps) {
  const sortedCars = [...cars].sort((a, b) => a.racePosition - b.racePosition);

  const formatTime = (seconds: number): string => {
    if (seconds <= 0 || seconds === Infinity) return '--:--.---';
    const mins = Math.floor(seconds / 60);
    const secs = (seconds % 60).toFixed(3);
    return `${mins}:${secs.padStart(6, '0')}`;
  };

  const formatGap = (car: CarTelemetry, leader: CarTelemetry): string => {
    if (car.racePosition === 1) return 'Leader';
    const gap = car.totalRaceTime - leader.totalRaceTime;
    if (gap < 60) return `+${gap.toFixed(1)}s`;
    return `+${Math.floor(gap / 60)}:${(gap % 60).toFixed(1).padStart(4, '0')}`;
  };

  const leader = sortedCars[0];

  return (
    <div className="leaderboard">
      <h3>Standings (Lap {leader?.currentLap || 1}/{totalLaps})</h3>
      <div className="leaderboard-list">
        {sortedCars.map((car) => (
          <div
            key={car.carId}
            className={`leaderboard-row ${car.isPlayerCar ? 'player' : ''}`}
          >
            <span className="position">P{car.racePosition}</span>
            <span className="driver">{car.driverName}</span>
            <span className="team">{car.teamName}</span>
            <span className="gap">{formatGap(car, leader)}</span>
            <span className="last-lap">{formatTime(car.lastLapTime)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
