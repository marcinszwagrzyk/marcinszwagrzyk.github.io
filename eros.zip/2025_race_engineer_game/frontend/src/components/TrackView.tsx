import { useEffect, useRef, useState } from 'react';
import { CarTelemetry } from '../types/game.types';
import './TrackView.css';

interface TrackViewProps {
  cars: CarTelemetry[];
}

export function TrackView({ cars }: TrackViewProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [trackPath, setTrackPath] = useState<SVGPathElement | null>(null);
  const [trackLength, setTrackLength] = useState(0);

  useEffect(() => {
    const loadTrack = async () => {
      try {
        const response = await fetch('/tracks/spa.svg');
        const svgText = await response.text();

        if (svgRef.current) {
          const container = svgRef.current.parentElement;
          if (container) {
            container.innerHTML = svgText;
            const svg = container.querySelector('svg');
            if (svg) {
              svg.setAttribute('width', '100%');
              svg.setAttribute('height', '100%');
              svg.setAttribute('viewBox', '0 0 800 600');

              const path = svg.querySelector('#trackPath') as SVGPathElement;
              if (path) {
                setTrackPath(path);
                setTrackLength(path.getTotalLength());
              }
            }
          }
        }
      } catch (error) {
        console.error('Failed to load track:', error);
      }
    };

    loadTrack();
  }, []);

  useEffect(() => {
    if (!trackPath || trackLength === 0) return;

    const svg = trackPath.ownerSVGElement;
    if (!svg) return;

    // Remove old car markers
    svg.querySelectorAll('.car-marker').forEach(el => el.remove());

    // Add car markers
    cars.forEach(car => {
      const position = car.trackPosition * trackLength;
      const point = trackPath.getPointAtLength(position);

      const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      circle.setAttribute('cx', String(point.x));
      circle.setAttribute('cy', String(point.y));
      circle.setAttribute('r', car.isPlayerCar ? '12' : '8');
      circle.setAttribute('class', `car-marker ${car.isPlayerCar ? 'player' : 'ai'}`);
      circle.setAttribute('fill', car.isPlayerCar ? '#ff0000' : getTeamColor(car.teamName));

      // Add position label
      const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      text.setAttribute('x', String(point.x));
      text.setAttribute('y', String(point.y + 4));
      text.setAttribute('text-anchor', 'middle');
      text.setAttribute('class', 'car-marker car-label');
      text.setAttribute('fill', '#ffffff');
      text.setAttribute('font-size', '10');
      text.setAttribute('font-weight', 'bold');
      text.textContent = String(car.racePosition);

      svg.appendChild(circle);
      svg.appendChild(text);
    });
  }, [cars, trackPath, trackLength]);

  return (
    <div className="track-view">
      <div className="track-container" ref={svgRef as any}>
        <div className="loading-track">Loading track...</div>
      </div>
    </div>
  );
}

function getTeamColor(teamName: string): string {
  const colors: Record<string, string> = {
    'Mercedes': '#00d2be',
    'Ferrari': '#dc0000',
    'McLaren': '#ff8700',
    'Aston Martin': '#006f62',
    'Red Bull Racing': '#0600ef'
  };
  return colors[teamName] || '#666666';
}
