import { DriverMessage } from '../types/game.types';
import './NotificationPanel.css';

interface NotificationPanelProps {
  messages: DriverMessage[];
}

export function NotificationPanel({ messages }: NotificationPanelProps) {
  const formatTime = (timestamp: number): string => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="notification-panel">
      <h3>Radio</h3>
      <div className="messages-list">
        {messages.length === 0 ? (
          <div className="no-messages">No messages yet...</div>
        ) : (
          messages.map((msg, index) => (
            <div key={index} className={`message ${msg.type.toLowerCase()}`}>
              <span className="message-time">{formatTime(msg.timestamp)}</span>
              <span className="message-text">{msg.message}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
