import { useEffect, useRef, useState, useCallback } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { RaceState, DriverMessage } from '../types/game.types';

export function useWebSocket() {
  const clientRef = useRef<Client | null>(null);
  const [raceState, setRaceState] = useState<RaceState | null>(null);
  const [messages, setMessages] = useState<DriverMessage[]>([]);
  const [connected, setConnected] = useState(false);

  const connect = useCallback(() => {
    const client = new Client({
      webSocketFactory: () => new SockJS('/ws'),
      onConnect: () => {
        setConnected(true);

        client.subscribe('/topic/race', (message) => {
          const state: RaceState = JSON.parse(message.body);
          setRaceState(state);
        });

        client.subscribe('/topic/messages', (message) => {
          const driverMessage: DriverMessage = JSON.parse(message.body);
          setMessages(prev => [...prev.slice(-9), driverMessage]);
        });
      },
      onDisconnect: () => {
        setConnected(false);
      },
      onStompError: (frame) => {
        console.error('STOMP error:', frame.headers['message']);
      }
    });

    client.activate();
    clientRef.current = client;
  }, []);

  const disconnect = useCallback(() => {
    if (clientRef.current) {
      clientRef.current.deactivate();
      clientRef.current = null;
    }
  }, []);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  return { raceState, messages, connected, clearMessages };
}
