export type TireCompound = 'SOFT' | 'MEDIUM' | 'HARD';
export type DriverOrder = 'PUSH' | 'NORMAL' | 'CONSERVE';
export type TimeOfDay = 'MORNING' | 'AFTERNOON' | 'EVENING' | 'NIGHT';
export type MessageType = 'INFO' | 'WARNING' | 'CRITICAL';

export interface CarTelemetry {
  carId: number;
  teamName: string;
  driverName: string;
  racePosition: number;
  currentLap: number;
  trackPosition: number;
  lastLapTime: number;
  bestLapTime: number;
  fuelLevel: number;
  tireWear: number;
  tireCompound: TireCompound;
  fatigueLevel: number;
  currentOrder: DriverOrder;
  inPit: boolean;
  isPlayerCar: boolean;
  totalRaceTime: number;
  offTrackCount: number;
}

export interface RaceState {
  trackName: string;
  totalLaps: number;
  leaderLap: number;
  elapsedTimeSeconds: number;
  timeOfDay: TimeOfDay;
  isPaused: boolean;
  isFinished: boolean;
  cars: CarTelemetry[];
  playerCar: CarTelemetry | null;
}

export interface DriverMessage {
  message: string;
  type: MessageType;
  carId: number;
  timestamp: number;
}

export interface OrderRequest {
  carId: number;
  order?: DriverOrder;
  tireCompound?: TireCompound;
}
