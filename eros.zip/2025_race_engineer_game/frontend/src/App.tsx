import { useState } from 'react';
import { useWebSocket } from './hooks/useWebSocket';
import { TrackView } from './components/TrackView';
import { Telemetry } from './components/Telemetry';
import { Leaderboard } from './components/Leaderboard';
import { DriverControls } from './components/DriverControls';
import { NotificationPanel } from './components/NotificationPanel';
import { createRace, startRace, pauseRace } from './services/api';
import './App.css';

function App() {
  const { raceState, messages, connected } = useWebSocket();
  const [loading, setLoading] = useState(false);

  const handleCreateRace = async () => {
    setLoading(true);
    await createRace();
    setLoading(false);
  };

  const handleStartRace = async () => {
    await startRace();
  };

  const handlePauseRace = async () => {
    await pauseRace();
  };

  const formatElapsedTime = (seconds: number): string => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="app">
      <header className="header">
        <h1>Race Engineer</h1>
        <div className="header-info">
          {raceState && (
            <>
              <span className="track-name">{raceState.trackName}</span>
              <span className="time-of-day">{raceState.timeOfDay}</span>
              <span className="elapsed-time">{formatElapsedTime(raceState.elapsedTimeSeconds)}</span>
            </>
          )}
          <span className={`connection-status ${connected ? 'connected' : ''}`}>
            {connected ? 'Connected' : 'Disconnected'}
          </span>
        </div>
        <div className="header-controls">
          {!raceState && (
            <button onClick={handleCreateRace} disabled={loading}>
              {loading ? 'Creating...' : 'New Race'}
            </button>
          )}
          {raceState && raceState.isPaused && !raceState.isFinished && (
            <button onClick={handleStartRace}>Start Race</button>
          )}
          {raceState && !raceState.isPaused && !raceState.isFinished && (
            <button onClick={handlePauseRace}>Pause Race</button>
          )}
          {raceState?.isFinished && (
            <button onClick={handleCreateRace}>New Race</button>
          )}
        </div>
      </header>

      {raceState?.isFinished && (
        <div className="race-finished-banner">
          RACE FINISHED - Final Position: P{raceState.playerCar?.racePosition}
        </div>
      )}

      <main className="main-content">
        <div className="track-section">
          <TrackView cars={raceState?.cars || []} />
        </div>

        <div className="sidebar">
          <Leaderboard cars={raceState?.cars || []} totalLaps={raceState?.totalLaps || 0} />
          <Telemetry car={raceState?.playerCar || null} />
          <DriverControls car={raceState?.playerCar || null} />
          <NotificationPanel messages={messages} />
        </div>
      </main>
    </div>
  );
}

export default App;
