package com.raceengineer.model;

import com.raceengineer.model.enums.TimeOfDay;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Race {
    private String trackName;
    private int totalLaps;
    private double elapsedTimeSeconds;
    private TimeOfDay timeOfDay;
    private List<Car> cars;
    private boolean isPaused;
    private boolean isFinished;
    private double trackLengthKm;
    private double baselapTimeSeconds;  // SPA base lap time ~105 seconds

    public Race(String trackName, int totalLaps, double trackLengthKm, double baseLapTimeSeconds) {
        this.trackName = trackName;
        this.totalLaps = totalLaps;
        this.trackLengthKm = trackLengthKm;
        this.baselapTimeSeconds = baseLapTimeSeconds;
        this.elapsedTimeSeconds = 0.0;
        this.timeOfDay = TimeOfDay.MORNING;
        this.cars = new ArrayList<>();
        this.isPaused = true;
        this.isFinished = false;
    }

    public String getTrackName() {
        return trackName;
    }

    public int getTotalLaps() {
        return totalLaps;
    }

    public double getElapsedTimeSeconds() {
        return elapsedTimeSeconds;
    }

    public void addElapsedTime(double seconds) {
        this.elapsedTimeSeconds += seconds;
        updateTimeOfDay();
    }

    public TimeOfDay getTimeOfDay() {
        return timeOfDay;
    }

    private void updateTimeOfDay() {
        // Simulate 6-hour race, time changes every 1.5 hours (5400 seconds game time)
        double gameTimeInHours = elapsedTimeSeconds / 3600.0;
        if (gameTimeInHours < 1.5) {
            timeOfDay = TimeOfDay.MORNING;
        } else if (gameTimeInHours < 3.0) {
            timeOfDay = TimeOfDay.AFTERNOON;
        } else if (gameTimeInHours < 4.5) {
            timeOfDay = TimeOfDay.EVENING;
        } else {
            timeOfDay = TimeOfDay.NIGHT;
        }
    }

    public List<Car> getCars() {
        return cars;
    }

    public void addCar(Car car) {
        cars.add(car);
    }

    public Car getPlayerCar() {
        return cars.stream()
                .filter(Car::isPlayerCar)
                .findFirst()
                .orElse(null);
    }

    public Car getCarById(int carId) {
        return cars.stream()
                .filter(car -> car.getId() == carId)
                .findFirst()
                .orElse(null);
    }

    public boolean isPaused() {
        return isPaused;
    }

    public void setPaused(boolean paused) {
        isPaused = paused;
    }

    public void start() {
        isPaused = false;
    }

    public void pause() {
        isPaused = true;
    }

    public boolean isFinished() {
        return isFinished;
    }

    public void setFinished(boolean finished) {
        isFinished = finished;
    }

    public double getTrackLengthKm() {
        return trackLengthKm;
    }

    public double getBaseLapTimeSeconds() {
        return baselapTimeSeconds;
    }

    public void updatePositions() {
        // Sort cars by total progress (current lap + track position)
        cars.sort((a, b) -> {
            double progressA = a.getCurrentLap() + a.getTrackPosition();
            double progressB = b.getCurrentLap() + b.getTrackPosition();
            return Double.compare(progressB, progressA); // Descending
        });

        for (int i = 0; i < cars.size(); i++) {
            cars.get(i).setRacePosition(i + 1);
        }
    }

    public int getLeaderLap() {
        return cars.stream()
                .mapToInt(Car::getCurrentLap)
                .max()
                .orElse(1);
    }

    public void checkRaceFinished() {
        Car leader = cars.stream()
                .min(Comparator.comparingInt(Car::getRacePosition))
                .orElse(null);

        if (leader != null && leader.getCurrentLap() > totalLaps) {
            isFinished = true;
            isPaused = true;
        }
    }
}
