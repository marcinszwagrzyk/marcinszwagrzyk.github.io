package com.raceengineer.controller;

import com.raceengineer.dto.OrderRequestDTO;
import com.raceengineer.dto.RaceStateDTO;
import com.raceengineer.model.Race;
import com.raceengineer.service.RaceSimulationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/race")
public class RaceController {

    private final RaceSimulationService raceService;

    @Autowired
    public RaceController(RaceSimulationService raceService) {
        this.raceService = raceService;
    }

    @PostMapping("/create")
    public ResponseEntity<RaceStateDTO> createRace() {
        Race race = raceService.createNewRace();
        return ResponseEntity.ok(RaceStateDTO.fromRace(race));
    }

    @PostMapping("/start")
    public ResponseEntity<Map<String, String>> startRace() {
        raceService.startRace();
        return ResponseEntity.ok(Map.of("status", "Race started"));
    }

    @PostMapping("/pause")
    public ResponseEntity<Map<String, String>> pauseRace() {
        raceService.pauseRace();
        return ResponseEntity.ok(Map.of("status", "Race paused"));
    }

    @GetMapping("/state")
    public ResponseEntity<RaceStateDTO> getState() {
        Race race = raceService.getCurrentRace();
        if (race == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(RaceStateDTO.fromRace(race));
    }

    @PostMapping("/order")
    public ResponseEntity<Map<String, String>> setOrder(@RequestBody OrderRequestDTO request) {
        raceService.setDriverOrder(request.getCarId(), request.getOrder());
        return ResponseEntity.ok(Map.of("status", "Order set to " + request.getOrder()));
    }

    @PostMapping("/pit")
    public ResponseEntity<Map<String, String>> callToPit(@RequestBody OrderRequestDTO request) {
        raceService.callToPit(request.getCarId(), request.getTireCompound());
        return ResponseEntity.ok(Map.of("status", "Called to pit with " + request.getTireCompound()));
    }
}
