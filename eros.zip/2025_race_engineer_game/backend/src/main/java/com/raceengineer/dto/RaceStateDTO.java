package com.raceengineer.dto;

import com.raceengineer.model.Race;
import com.raceengineer.model.enums.TimeOfDay;

import java.util.List;
import java.util.stream.Collectors;

public class RaceStateDTO {
    private String trackName;
    private int totalLaps;
    private int leaderLap;
    private double elapsedTimeSeconds;
    private TimeOfDay timeOfDay;
    private boolean isPaused;
    private boolean isFinished;
    private List<CarTelemetryDTO> cars;
    private CarTelemetryDTO playerCar;

    public RaceStateDTO() {}

    public static RaceStateDTO fromRace(Race race) {
        RaceStateDTO dto = new RaceStateDTO();
        dto.trackName = race.getTrackName();
        dto.totalLaps = race.getTotalLaps();
        dto.leaderLap = race.getLeaderLap();
        dto.elapsedTimeSeconds = race.getElapsedTimeSeconds();
        dto.timeOfDay = race.getTimeOfDay();
        dto.isPaused = race.isPaused();
        dto.isFinished = race.isFinished();
        dto.cars = race.getCars().stream()
                .map(CarTelemetryDTO::fromCar)
                .collect(Collectors.toList());
        if (race.getPlayerCar() != null) {
            dto.playerCar = CarTelemetryDTO.fromCar(race.getPlayerCar());
        }
        return dto;
    }

    // Getters
    public String getTrackName() { return trackName; }
    public int getTotalLaps() { return totalLaps; }
    public int getLeaderLap() { return leaderLap; }
    public double getElapsedTimeSeconds() { return elapsedTimeSeconds; }
    public TimeOfDay getTimeOfDay() { return timeOfDay; }
    public boolean isPaused() { return isPaused; }
    public boolean isFinished() { return isFinished; }
    public List<CarTelemetryDTO> getCars() { return cars; }
    public CarTelemetryDTO getPlayerCar() { return playerCar; }
}
