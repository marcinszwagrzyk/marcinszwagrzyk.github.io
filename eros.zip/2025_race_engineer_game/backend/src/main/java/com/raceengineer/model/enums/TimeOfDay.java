package com.raceengineer.model.enums;

public enum TimeOfDay {
    MORNING(1.0),
    AFTERNOON(1.0),
    EVENING(1.5),
    NIGHT(2.0);

    private final double fatigueMultiplier;

    TimeOfDay(double fatigueMultiplier) {
        this.fatigueMultiplier = fatigueMultiplier;
    }

    public double getFatigueMultiplier() {
        return fatigueMultiplier;
    }
}
