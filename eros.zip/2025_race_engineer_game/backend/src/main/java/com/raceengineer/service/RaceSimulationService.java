package com.raceengineer.service;

import com.raceengineer.dto.DriverMessageDTO;
import com.raceengineer.dto.RaceStateDTO;
import com.raceengineer.model.Car;
import com.raceengineer.model.Driver;
import com.raceengineer.model.Race;
import com.raceengineer.model.enums.DriverOrder;
import com.raceengineer.model.enums.TireCompound;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

@Service
public class RaceSimulationService {

    private static final double TICK_INTERVAL_SECONDS = 0.1; // 100ms real time = 1 game second
    private static final double GAME_TIME_MULTIPLIER = 10.0; // 10x speed
    private static final double PIT_STOP_DURATION = 25.0; // seconds

    private Race currentRace;
    private final FatigueService fatigueService;
    private final AIDriverService aiDriverService;
    private final SimpMessagingTemplate messagingTemplate;
    private final Random random = new Random();
    private final List<DriverMessageDTO> pendingMessages = new CopyOnWriteArrayList<>();

    // Track state for message throttling
    private final List<Integer> sentFatigueWarning = new ArrayList<>();
    private final List<Integer> sentTireWarning = new ArrayList<>();
    private final List<Integer> sentFuelWarning = new ArrayList<>();

    @Autowired
    public RaceSimulationService(FatigueService fatigueService,
                                  AIDriverService aiDriverService,
                                  SimpMessagingTemplate messagingTemplate) {
        this.fatigueService = fatigueService;
        this.aiDriverService = aiDriverService;
        this.messagingTemplate = messagingTemplate;
    }

    public Race createNewRace() {
        // SPA-Francorchamps: 7.004 km, base lap time ~105 seconds
        currentRace = new Race("SPA-Francorchamps", 20, 7.004, 105.0);

        // Reset message tracking
        sentFatigueWarning.clear();
        sentTireWarning.clear();
        sentFuelWarning.clear();

        // Create player car
        Driver playerDriver = new Driver("M. Verstappen", 0.95);
        Car playerCar = new Car(1, "Red Bull Racing", playerDriver, true);
        playerCar.setTireCompound(TireCompound.MEDIUM);
        currentRace.addCar(playerCar);

        // Create AI cars
        String[][] aiTeams = {
            {"L. Hamilton", "Mercedes"},
            {"C. Leclerc", "Ferrari"},
            {"L. Norris", "McLaren"},
            {"F. Alonso", "Aston Martin"},
            {"G. Russell", "Mercedes"},
            {"C. Sainz", "Ferrari"}
        };

        for (int i = 0; i < aiTeams.length; i++) {
            double skill = 0.85 + random.nextDouble() * 0.1; // 0.85 - 0.95
            Driver aiDriver = new Driver(aiTeams[i][0], skill);
            Car aiCar = new Car(i + 2, aiTeams[i][1], aiDriver, false);
            aiCar.setTireCompound(TireCompound.MEDIUM);
            currentRace.addCar(aiCar);
        }

        // Randomize starting positions slightly
        for (Car car : currentRace.getCars()) {
            car.setTrackPosition(random.nextDouble() * 0.05);
        }

        return currentRace;
    }

    public void startRace() {
        if (currentRace != null) {
            currentRace.start();
        }
    }

    public void pauseRace() {
        if (currentRace != null) {
            currentRace.pause();
        }
    }

    public Race getCurrentRace() {
        return currentRace;
    }

    public void setDriverOrder(int carId, DriverOrder order) {
        if (currentRace != null) {
            Car car = currentRace.getCarById(carId);
            if (car != null && car.isPlayerCar()) {
                car.getDriver().setCurrentOrder(order);
            }
        }
    }

    public void callToPit(int carId, TireCompound compound) {
        if (currentRace != null) {
            Car car = currentRace.getCarById(carId);
            if (car != null && car.isPlayerCar()) {
                car.setInPit(true);
                car.setTireCompound(compound);
            }
        }
    }

    @Scheduled(fixedRate = 100) // 100ms
    public void gameTick() {
        if (currentRace == null || currentRace.isPaused() || currentRace.isFinished()) {
            return;
        }

        double gameSeconds = TICK_INTERVAL_SECONDS * GAME_TIME_MULTIPLIER;
        currentRace.addElapsedTime(gameSeconds);

        for (Car car : currentRace.getCars()) {
            updateCar(car, gameSeconds);
        }

        currentRace.updatePositions();
        currentRace.checkRaceFinished();

        // Send state update via WebSocket
        RaceStateDTO stateDTO = RaceStateDTO.fromRace(currentRace);
        messagingTemplate.convertAndSend("/topic/race", stateDTO);

        // Send any pending messages
        for (DriverMessageDTO msg : pendingMessages) {
            messagingTemplate.convertAndSend("/topic/messages", msg);
        }
        pendingMessages.clear();
    }

    private void updateCar(Car car, double gameSeconds) {
        // Handle pit stop
        if (car.isInPit()) {
            car.addTotalRaceTime(PIT_STOP_DURATION);
            car.pitStop(car.getTireCompound());
            addMessage(DriverMessageDTO.info(car.getId(), "Pit stop complete!"));
            return;
        }

        // Calculate lap time components
        double baseLapTime = currentRace.getBaseLapTimeSeconds();
        double skillVariance = (1.0 - car.getDriver().getSkill()) * 2.0; // 0-2 seconds variance
        double randomVariance = (random.nextDouble() - 0.5) * 2.0; // -1 to +1 seconds

        // Tire compound base time
        baseLapTime = car.getTireCompound().getBaseLapTimeSeconds();

        // Fatigue modifier
        double fatigueModifier = fatigueService.getLapTimeModifierFromFatigue(car.getDriver());

        // Tire wear modifier (0.03s per 10% wear)
        double tireModifier = (car.getTireWear() / 10.0) * 0.03;

        // Order modifier
        double orderModifier = car.getDriver().getCurrentOrder().getLapTimeModifierSeconds();

        // Calculate current speed as track progress per second
        double expectedLapTime = baseLapTime + skillVariance + randomVariance + fatigueModifier + tireModifier + orderModifier;

        // Off-track penalty
        if (car.isOffTrack()) {
            expectedLapTime += 5.0; // 5 second penalty
            car.setOffTrack(false);
            if (car.isPlayerCar()) {
                addMessage(DriverMessageDTO.warning(car.getId(), "Went off track! Lost time."));
            }
        }

        double progressPerSecond = 1.0 / expectedLapTime;
        double progressThisTick = progressPerSecond * gameSeconds;

        car.setTrackPosition(car.getTrackPosition() + progressThisTick);
        car.addLapTime(gameSeconds);
        car.addTotalRaceTime(gameSeconds);

        // Check if lap completed
        if (car.getTrackPosition() >= 1.0) {
            completeLap(car);
        }

        // AI behavior
        if (!car.isPlayerCar()) {
            aiDriverService.updateAIStrategy(car);
            if (aiDriverService.shouldPit(car)) {
                int remainingLaps = currentRace.getTotalLaps() - car.getCurrentLap();
                TireCompound newCompound = aiDriverService.selectTireCompound(car, remainingLaps);
                car.setInPit(true);
                car.setTireCompound(newCompound);
            }
        }

        // Generate driver messages for player car
        if (car.isPlayerCar()) {
            checkAndSendMessages(car);
        }

        // Check off-track risk
        fatigueService.checkOffTrack(car);
    }

    private void completeLap(Car car) {
        // Consume tire and fuel
        double tireWear = car.getTireCompound().getDegradationPerLap();
        double fuelConsumption = car.getDriver().getCurrentOrder().getFuelConsumptionPerLap();

        car.addTireWear(tireWear);
        car.consumeFuel(fuelConsumption);

        // Update fatigue
        fatigueService.updateFatigue(car, currentRace);

        // Complete the lap
        car.completeLap();

        // Check for overtakes (simplified)
        checkOvertakes(car);
    }

    private void checkOvertakes(Car car) {
        int currentPos = car.getRacePosition();
        for (Car other : currentRace.getCars()) {
            if (other.getId() != car.getId()) {
                // Simple position-based overtake detection
                if (other.getRacePosition() > currentPos &&
                    other.getCurrentLap() == car.getCurrentLap()) {
                    car.getDriver().incrementOvertakeCount();
                }
            }
        }
    }

    private void checkAndSendMessages(Car car) {
        int carId = car.getId();
        Driver driver = car.getDriver();

        // Fatigue warnings
        if (driver.getFatigueLevel() > 50 && !sentFatigueWarning.contains(carId)) {
            addMessage(DriverMessageDTO.warning(carId, "I'm starting to feel tired..."));
            sentFatigueWarning.add(carId);
        }
        if (driver.getFatigueLevel() > 70 && sentFatigueWarning.size() == 1) {
            addMessage(DriverMessageDTO.critical(carId, "I'm exhausted! Need to conserve!"));
            sentFatigueWarning.add(carId);
        }

        // Tire warnings
        if (car.getTireWear() > 60 && !sentTireWarning.contains(carId)) {
            addMessage(DriverMessageDTO.warning(carId, "Tires are wearing out..."));
            sentTireWarning.add(carId);
        }
        if (car.getTireWear() > 80 && sentTireWarning.size() == 1) {
            addMessage(DriverMessageDTO.critical(carId, "Tires are gone! Need to pit!"));
            sentTireWarning.add(carId);
        }

        // Fuel warnings
        if (car.getFuelLevel() < 25 && !sentFuelWarning.contains(carId)) {
            addMessage(DriverMessageDTO.warning(carId, "Fuel getting low..."));
            sentFuelWarning.add(carId);
        }
        if (car.getFuelLevel() < 10 && sentFuelWarning.size() == 1) {
            addMessage(DriverMessageDTO.critical(carId, "Running on fumes! Pit NOW!"));
            sentFuelWarning.add(carId);
        }
    }

    private void addMessage(DriverMessageDTO message) {
        pendingMessages.add(message);
    }
}
