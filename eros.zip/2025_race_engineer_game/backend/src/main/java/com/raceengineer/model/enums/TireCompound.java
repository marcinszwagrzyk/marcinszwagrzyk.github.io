package com.raceengineer.model.enums;

public enum TireCompound {
    SOFT(3.0, 105.0),      // 3% wear per lap, fastest base time
    MEDIUM(2.0, 106.5),    // 2% wear per lap, medium base time
    HARD(1.5, 108.0);      // 1.5% wear per lap, slowest base time

    private final double degradationPerLap;
    private final double baselapTimeSeconds;

    TireCompound(double degradationPerLap, double baseLapTimeSeconds) {
        this.degradationPerLap = degradationPerLap;
        this.baselapTimeSeconds = baseLapTimeSeconds;
    }

    public double getDegradationPerLap() {
        return degradationPerLap;
    }

    public double getBaseLapTimeSeconds() {
        return baselapTimeSeconds;
    }
}
