package com.raceengineer.model;

import com.raceengineer.model.enums.TireCompound;

public class Car {
    private int id;
    private String teamName;
    private Driver driver;
    private double trackPosition;      // 0.0 - 1.0, position on track
    private int currentLap;
    private double currentLapTime;     // seconds
    private double lastLapTime;        // seconds
    private double bestLapTime;        // seconds
    private double fuelLevel;          // 0-100%
    private double tireWear;           // 0-100% (100 = worn out)
    private TireCompound tireCompound;
    private boolean inPit;
    private boolean isPlayerCar;
    private int racePosition;
    private double totalRaceTime;      // seconds
    private boolean offTrack;
    private int offTrackCount;

    public Car(int id, String teamName, Driver driver, boolean isPlayerCar) {
        this.id = id;
        this.teamName = teamName;
        this.driver = driver;
        this.isPlayerCar = isPlayerCar;
        this.trackPosition = 0.0;
        this.currentLap = 1;
        this.currentLapTime = 0.0;
        this.lastLapTime = 0.0;
        this.bestLapTime = Double.MAX_VALUE;
        this.fuelLevel = 100.0;
        this.tireWear = 0.0;
        this.tireCompound = TireCompound.MEDIUM;
        this.inPit = false;
        this.racePosition = id;
        this.totalRaceTime = 0.0;
        this.offTrack = false;
        this.offTrackCount = 0;
    }

    public int getId() {
        return id;
    }

    public String getTeamName() {
        return teamName;
    }

    public Driver getDriver() {
        return driver;
    }

    public double getTrackPosition() {
        return trackPosition;
    }

    public void setTrackPosition(double trackPosition) {
        this.trackPosition = trackPosition;
    }

    public int getCurrentLap() {
        return currentLap;
    }

    public void setCurrentLap(int currentLap) {
        this.currentLap = currentLap;
    }

    public void incrementLap() {
        this.currentLap++;
    }

    public double getCurrentLapTime() {
        return currentLapTime;
    }

    public void setCurrentLapTime(double currentLapTime) {
        this.currentLapTime = currentLapTime;
    }

    public void addLapTime(double time) {
        this.currentLapTime += time;
    }

    public double getLastLapTime() {
        return lastLapTime;
    }

    public void setLastLapTime(double lastLapTime) {
        this.lastLapTime = lastLapTime;
    }

    public double getBestLapTime() {
        return bestLapTime;
    }

    public void updateBestLapTime(double lapTime) {
        if (lapTime < this.bestLapTime) {
            this.bestLapTime = lapTime;
        }
    }

    public double getFuelLevel() {
        return fuelLevel;
    }

    public void setFuelLevel(double fuelLevel) {
        this.fuelLevel = Math.min(100.0, Math.max(0.0, fuelLevel));
    }

    public void consumeFuel(double amount) {
        setFuelLevel(this.fuelLevel - amount);
    }

    public double getTireWear() {
        return tireWear;
    }

    public void setTireWear(double tireWear) {
        this.tireWear = Math.min(100.0, Math.max(0.0, tireWear));
    }

    public void addTireWear(double amount) {
        setTireWear(this.tireWear + amount);
    }

    public TireCompound getTireCompound() {
        return tireCompound;
    }

    public void setTireCompound(TireCompound tireCompound) {
        this.tireCompound = tireCompound;
    }

    public boolean isInPit() {
        return inPit;
    }

    public void setInPit(boolean inPit) {
        this.inPit = inPit;
    }

    public boolean isPlayerCar() {
        return isPlayerCar;
    }

    public int getRacePosition() {
        return racePosition;
    }

    public void setRacePosition(int racePosition) {
        this.racePosition = racePosition;
    }

    public double getTotalRaceTime() {
        return totalRaceTime;
    }

    public void setTotalRaceTime(double totalRaceTime) {
        this.totalRaceTime = totalRaceTime;
    }

    public void addTotalRaceTime(double time) {
        this.totalRaceTime += time;
    }

    public boolean isOffTrack() {
        return offTrack;
    }

    public void setOffTrack(boolean offTrack) {
        this.offTrack = offTrack;
        if (offTrack) {
            this.offTrackCount++;
        }
    }

    public int getOffTrackCount() {
        return offTrackCount;
    }

    public void completeLap() {
        this.lastLapTime = this.currentLapTime;
        updateBestLapTime(this.currentLapTime);
        this.currentLapTime = 0.0;
        this.trackPosition = 0.0;
        this.currentLap++;
    }

    public void pitStop(TireCompound newCompound) {
        this.tireWear = 0.0;
        this.tireCompound = newCompound;
        this.fuelLevel = 100.0;
        this.inPit = false;
    }

    public boolean needsFuel() {
        return fuelLevel < 15;
    }

    public boolean needsTires() {
        return tireWear > 70;
    }
}
