package com.raceengineer.service;

import com.raceengineer.model.Car;
import com.raceengineer.model.Driver;
import com.raceengineer.model.Race;
import org.springframework.stereotype.Service;

@Service
public class FatigueService {

    private static final double BASE_FATIGUE_PER_LAP = 0.5;
    private static final double OVERTAKE_FATIGUE = 2.0;

    public void updateFatigue(Car car, Race race) {
        Driver driver = car.getDriver();

        // Base fatigue
        double fatigue = BASE_FATIGUE_PER_LAP;

        // Time of day modifier
        fatigue *= race.getTimeOfDay().getFatigueMultiplier();

        // Tempo modifier
        fatigue *= driver.getCurrentOrder().getFatigueMultiplier();

        // Overtake modifier (reset each lap)
        fatigue += driver.getOvertakeCount() * OVERTAKE_FATIGUE;
        driver.resetOvertakeCount();

        driver.addFatigue(fatigue);
    }

    public boolean checkOffTrack(Car car) {
        Driver driver = car.getDriver();

        if (driver.getFatigueLevel() > 70) {
            double offTrackChance = (driver.getFatigueLevel() - 70) * 0.005; // 0.5% per point over 70
            if (Math.random() < offTrackChance) {
                car.setOffTrack(true);
                return true;
            }
        }
        return false;
    }

    public double getLapTimeModifierFromFatigue(Driver driver) {
        // 0.02s slower per 10% fatigue
        return (driver.getFatigueLevel() / 10.0) * 0.02;
    }
}
