package com.raceengineer.model.enums;

public enum DriverOrder {
    PUSH(-2.0, 2.0, 2.0),       // Faster lap times, more tire/fuel consumption, faster fatigue
    NORMAL(0.0, 1.5, 1.0),      // Baseline
    CONSERVE(3.0, 1.0, 0.5);    // Slower lap times, less consumption, slower fatigue

    private final double lapTimeModifierSeconds;
    private final double fuelConsumptionPerLap;
    private final double fatigueMultiplier;

    DriverOrder(double lapTimeModifierSeconds, double fuelConsumptionPerLap, double fatigueMultiplier) {
        this.lapTimeModifierSeconds = lapTimeModifierSeconds;
        this.fuelConsumptionPerLap = fuelConsumptionPerLap;
        this.fatigueMultiplier = fatigueMultiplier;
    }

    public double getLapTimeModifierSeconds() {
        return lapTimeModifierSeconds;
    }

    public double getFuelConsumptionPerLap() {
        return fuelConsumptionPerLap;
    }

    public double getFatigueMultiplier() {
        return fatigueMultiplier;
    }
}
