package com.raceengineer.service;

import com.raceengineer.model.Car;
import com.raceengineer.model.Driver;
import com.raceengineer.model.enums.DriverOrder;
import com.raceengineer.model.enums.TireCompound;
import org.springframework.stereotype.Service;

@Service
public class AIDriverService {

    public void updateAIStrategy(Car car) {
        Driver driver = car.getDriver();

        // Adjust tempo based on conditions
        if (driver.getFatigueLevel() > 60) {
            driver.setCurrentOrder(DriverOrder.CONSERVE);
        } else if (car.getTireWear() > 60) {
            driver.setCurrentOrder(DriverOrder.CONSERVE);
        } else if (car.getFuelLevel() < 30) {
            driver.setCurrentOrder(DriverOrder.CONSERVE);
        } else if (car.getTireWear() < 30 && car.getFuelLevel() > 50 && driver.getFatigueLevel() < 40) {
            driver.setCurrentOrder(DriverOrder.PUSH);
        } else {
            driver.setCurrentOrder(DriverOrder.NORMAL);
        }
    }

    public boolean shouldPit(Car car) {
        // AI decision to pit
        if (car.getFuelLevel() < 10) {
            return true;
        }
        if (car.getTireWear() > 85) {
            return true;
        }
        // Strategic pit stop at certain tire wear threshold
        if (car.getTireWear() > 60 && car.getFuelLevel() < 40) {
            return true;
        }
        return false;
    }

    public TireCompound selectTireCompound(Car car, int remainingLaps) {
        // Simple strategy based on remaining laps
        if (remainingLaps <= 10) {
            return TireCompound.SOFT;
        } else if (remainingLaps <= 25) {
            return TireCompound.MEDIUM;
        } else {
            return TireCompound.HARD;
        }
    }
}
