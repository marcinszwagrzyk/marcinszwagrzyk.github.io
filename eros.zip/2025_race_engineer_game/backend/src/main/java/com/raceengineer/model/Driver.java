package com.raceengineer.model;

import com.raceengineer.model.enums.DriverOrder;

public class Driver {
    private String name;
    private double fatigueLevel;       // 0-100
    private double skill;              // 0-1, affects lap time variance
    private DriverOrder currentOrder;
    private int overtakeCount;

    public Driver(String name, double skill) {
        this.name = name;
        this.skill = skill;
        this.fatigueLevel = 0.0;
        this.currentOrder = DriverOrder.NORMAL;
        this.overtakeCount = 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getFatigueLevel() {
        return fatigueLevel;
    }

    public void setFatigueLevel(double fatigueLevel) {
        this.fatigueLevel = Math.min(100.0, Math.max(0.0, fatigueLevel));
    }

    public void addFatigue(double amount) {
        setFatigueLevel(this.fatigueLevel + amount);
    }

    public double getSkill() {
        return skill;
    }

    public void setSkill(double skill) {
        this.skill = skill;
    }

    public DriverOrder getCurrentOrder() {
        return currentOrder;
    }

    public void setCurrentOrder(DriverOrder currentOrder) {
        this.currentOrder = currentOrder;
    }

    public int getOvertakeCount() {
        return overtakeCount;
    }

    public void incrementOvertakeCount() {
        this.overtakeCount++;
    }

    public void resetOvertakeCount() {
        this.overtakeCount = 0;
    }

    public boolean isTired() {
        return fatigueLevel > 50;
    }

    public boolean isExhausted() {
        return fatigueLevel > 70;
    }
}
