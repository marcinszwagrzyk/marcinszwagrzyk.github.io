package com.raceengineer.dto;

public class DriverMessageDTO {
    private String message;
    private String type;  // INFO, WARNING, CRITICAL
    private int carId;
    private long timestamp;

    public DriverMessageDTO() {}

    public DriverMessageDTO(int carId, String message, String type) {
        this.carId = carId;
        this.message = message;
        this.type = type;
        this.timestamp = System.currentTimeMillis();
    }

    public static DriverMessageDTO info(int carId, String message) {
        return new DriverMessageDTO(carId, message, "INFO");
    }

    public static DriverMessageDTO warning(int carId, String message) {
        return new DriverMessageDTO(carId, message, "WARNING");
    }

    public static DriverMessageDTO critical(int carId, String message) {
        return new DriverMessageDTO(carId, message, "CRITICAL");
    }

    public String getMessage() { return message; }
    public String getType() { return type; }
    public int getCarId() { return carId; }
    public long getTimestamp() { return timestamp; }
}
