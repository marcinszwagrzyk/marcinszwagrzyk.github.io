package com.raceengineer.dto;

import com.raceengineer.model.enums.DriverOrder;
import com.raceengineer.model.enums.TireCompound;

public class OrderRequestDTO {
    private int carId;
    private DriverOrder order;
    private TireCompound tireCompound;

    public OrderRequestDTO() {}

    public int getCarId() { return carId; }
    public void setCarId(int carId) { this.carId = carId; }

    public DriverOrder getOrder() { return order; }
    public void setOrder(DriverOrder order) { this.order = order; }

    public TireCompound getTireCompound() { return tireCompound; }
    public void setTireCompound(TireCompound tireCompound) { this.tireCompound = tireCompound; }
}
