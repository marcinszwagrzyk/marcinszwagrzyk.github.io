package com.raceengineer.dto;

import com.raceengineer.model.Car;
import com.raceengineer.model.enums.DriverOrder;
import com.raceengineer.model.enums.TireCompound;

public class CarTelemetryDTO {
    private int carId;
    private String teamName;
    private String driverName;
    private int racePosition;
    private int currentLap;
    private double trackPosition;
    private double lastLapTime;
    private double bestLapTime;
    private double fuelLevel;
    private double tireWear;
    private TireCompound tireCompound;
    private double fatigueLevel;
    private DriverOrder currentOrder;
    private boolean inPit;
    private boolean isPlayerCar;
    private double totalRaceTime;
    private int offTrackCount;

    public CarTelemetryDTO() {}

    public static CarTelemetryDTO fromCar(Car car) {
        CarTelemetryDTO dto = new CarTelemetryDTO();
        dto.carId = car.getId();
        dto.teamName = car.getTeamName();
        dto.driverName = car.getDriver().getName();
        dto.racePosition = car.getRacePosition();
        dto.currentLap = car.getCurrentLap();
        dto.trackPosition = car.getTrackPosition();
        dto.lastLapTime = car.getLastLapTime();
        dto.bestLapTime = car.getBestLapTime() == Double.MAX_VALUE ? 0 : car.getBestLapTime();
        dto.fuelLevel = car.getFuelLevel();
        dto.tireWear = car.getTireWear();
        dto.tireCompound = car.getTireCompound();
        dto.fatigueLevel = car.getDriver().getFatigueLevel();
        dto.currentOrder = car.getDriver().getCurrentOrder();
        dto.inPit = car.isInPit();
        dto.isPlayerCar = car.isPlayerCar();
        dto.totalRaceTime = car.getTotalRaceTime();
        dto.offTrackCount = car.getOffTrackCount();
        return dto;
    }

    // Getters
    public int getCarId() { return carId; }
    public String getTeamName() { return teamName; }
    public String getDriverName() { return driverName; }
    public int getRacePosition() { return racePosition; }
    public int getCurrentLap() { return currentLap; }
    public double getTrackPosition() { return trackPosition; }
    public double getLastLapTime() { return lastLapTime; }
    public double getBestLapTime() { return bestLapTime; }
    public double getFuelLevel() { return fuelLevel; }
    public double getTireWear() { return tireWear; }
    public TireCompound getTireCompound() { return tireCompound; }
    public double getFatigueLevel() { return fatigueLevel; }
    public DriverOrder getCurrentOrder() { return currentOrder; }
    public boolean isInPit() { return inPit; }
    public boolean isPlayerCar() { return isPlayerCar; }
    public double getTotalRaceTime() { return totalRaceTime; }
    public int getOffTrackCount() { return offTrackCount; }
}
